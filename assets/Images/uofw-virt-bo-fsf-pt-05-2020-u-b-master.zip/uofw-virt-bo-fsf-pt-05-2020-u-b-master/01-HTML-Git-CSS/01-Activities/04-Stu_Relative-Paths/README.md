# Relative Paths

## Instructions

* Correctly link the three `style.css` files found in the `public` directory to the `index.html` file to ensure the HTML file renders according to the following image:

![](html-css-mockup.png)

* Do not move any of the files. 

## Hint(s):

* You only need to change the relative path in the `<link>` tags.