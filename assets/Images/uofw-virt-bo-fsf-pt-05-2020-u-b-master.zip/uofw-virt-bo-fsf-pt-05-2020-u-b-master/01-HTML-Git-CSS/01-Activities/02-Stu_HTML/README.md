# HTML

## Instructions

Using only HTML, create a simple portfolio similar to the design in the following image:

![](html-mockup.png)
