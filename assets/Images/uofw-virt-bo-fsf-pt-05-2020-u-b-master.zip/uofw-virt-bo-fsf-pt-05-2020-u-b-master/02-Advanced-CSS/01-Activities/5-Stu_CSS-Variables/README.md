# CSS Variables

In this activity you will take a stylesheet and extract the colors into CSS Variables

## Instructions

* Using the stylesheet provided. Place five CSS Variables on the root of the document, extracting the appropriate color values from the CSS provided.

* The five variables should be named:

  * light

  * light-blue

  * sapphire

  * dark-blue

  * dark